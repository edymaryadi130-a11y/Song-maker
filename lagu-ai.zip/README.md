# Lagu AI

Aplikasi Android pembuat lagu (ala Suno) berbasis Gemini API (model Lyria).

## Cara pakai
1. Dapatkan kunci API di Google AI Studio.
2. Buka aplikasi, tempel kunci API, tekan **Simpan kunci**.
3. Pilih genre, vokal, bahasa. Isi deskripsi lagu dan/atau lirik sendiri.
4. Tekan **Buat Lagu**, tunggu 1-3 menit, lalu putar atau simpan ke folder Download.

Kunci API disimpan hanya di HP kamu (penyimpanan privat aplikasi), tidak ditanam di kode.

## Cara build APK lewat GitHub
1. Buat repository baru di GitHub, lalu unggah semua isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** > workflow **Build APK** > otomatis jalan setiap push (atau tekan **Run workflow**).
3. Setelah hijau (sekitar 3-6 menit), buka run-nya dan unduh artifact **LaguAI-apk**.
4. Ekstrak zip-nya, pasang `app-debug.apk` di HP (izinkan "install dari sumber tidak dikenal").

## Tulis lirik gratis
Tombol **Tulis lirik otomatis (gratis)** memakai model teks Gemini yang tersedia di Free Tier, jadi tidak butuh billing. Lirik masuk ke kolom lirik dan bisa diedit. Pembuatan audio (Lyria) tetap butuh akun berbayar.

## Catatan
- Model default `lyria-3.5` (lagu penuh). Untuk klip 30 detik isi kolom Model dengan `lyria-3-clip-preview`.
- Nama model masih berstatus preview dan bisa berubah. Kalau muncul error 404, cek nama model terbaru di dokumentasi Gemini API (Music generation).
- Pembuatan musik lewat API berbayar per lagu dan hasil tiap panggilan bisa berbeda walau prompt sama.
- Minimum Android 10 (API 29).
