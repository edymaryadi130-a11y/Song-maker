package com.laguai.app

import android.content.ContentValues
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/interactions"
        private const val DEFAULT_MODEL = "lyria-3.5"
        private const val PREFS = "lagu_ai_prefs"
    }

    private class ApiError(val code: Int, message: String) : Exception(message)

    private class Parsed {
        val texts = mutableListOf<String>()
        var audioB64: String? = null
    }

    private val executor = Executors.newSingleThreadExecutor()
    private var player: MediaPlayer? = null
    private var songFile: File? = null
    private var songExt = "mp3"

    private lateinit var keyInput: TextInputEditText
    private lateinit var modelInput: TextInputEditText
    private lateinit var descInput: TextInputEditText
    private lateinit var lyricsInput: TextInputEditText
    private lateinit var genreSpinner: Spinner
    private lateinit var vocalSpinner: Spinner
    private lateinit var langSpinner: Spinner
    private lateinit var generateBtn: MaterialButton
    private lateinit var playBtn: MaterialButton
    private lateinit var saveBtn: MaterialButton
    private lateinit var progress: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var lyricsOut: TextView
    private lateinit var resultGroup: LinearLayout

    private val genres = listOf(
        "Pop", "Rock", "Dangdut", "Hip-hop", "R&B", "EDM", "Akustik / Folk",
        "Jazz", "Lo-fi", "Orkestra sinematik", "Reggae", "Metal", "Country"
    )
    private val vocals = listOf("Vokal wanita", "Vokal pria", "Duet pria & wanita", "Instrumental (tanpa vokal)")
    private val languageLabels = listOf(
        "Bahasa Indonesia", "English", "Jawa", "Sunda", "Melayu", "Spanyol", "Jepang", "Korea"
    )
    private val languageNames = listOf(
        "Indonesian", "English", "Javanese", "Sundanese", "Malay", "Spanish", "Japanese", "Korean"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        keyInput.setText(prefs.getString("api_key", ""))
        modelInput.setText(prefs.getString("model", DEFAULT_MODEL))
    }

    // ---------- UI ----------

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
        setContentView(scroll)

        add(root, TextView(this).apply {
            text = "Lagu AI"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
        }, 0)
        add(root, TextView(this).apply {
            text = "Bikin lagu lengkap dengan vokal dari deskripsi atau liriknya sendiri. Ditenagai Gemini API (Lyria)."
            textSize = 14f
        }, 4)

        // API key
        val (keyLayout, key) = field("Kunci API Gemini", password = true)
        keyInput = key
        add(root, keyLayout, 20)
        add(root, MaterialButton(this).apply {
            text = "Simpan kunci"
            setOnClickListener {
                val k = keyInput.text.toString().trim()
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("api_key", k).apply()
                toast(if (k.isEmpty()) "Kunci dikosongkan" else "Kunci API tersimpan di HP ini")
            }
        }, 8)

        // Song settings
        genreSpinner = spinner(genres)
        vocalSpinner = spinner(vocals)
        langSpinner = spinner(languageLabels)
        add(root, label("Genre"), 20)
        add(root, genreSpinner, 0)
        add(root, label("Vokal"), 12)
        add(root, vocalSpinner, 0)
        add(root, label("Bahasa lirik"), 12)
        add(root, langSpinner, 0)

        val (descLayout, desc) = field("Deskripsi lagu (tema, suasana, cerita)", lines = 3)
        descInput = desc
        add(root, descLayout, 16)

        val (lyricsLayout, lyrics) = field("Lirik sendiri (opsional)", lines = 5)
        lyricsInput = lyrics
        add(root, lyricsLayout, 12)

        val (modelLayout, model) = field("Model (lyria-3.5 = lagu penuh, lyria-3-clip-preview = 30 detik)")
        modelInput = model
        add(root, modelLayout, 12)

        generateBtn = MaterialButton(this).apply {
            text = "Buat Lagu"
            setOnClickListener { onGenerate() }
        }
        add(root, generateBtn, 20)

        progress = ProgressBar(this).apply {
            isIndeterminate = true
            visibility = View.GONE
        }
        add(root, progress, 12)

        statusText = TextView(this).apply { textSize = 14f }
        add(root, statusText, 8)

        // Result
        resultGroup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        playBtn = MaterialButton(this).apply {
            text = "Putar"
            setOnClickListener { togglePlay() }
        }
        saveBtn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Simpan ke folder Download"
            setOnClickListener { saveToDownloads() }
        }
        lyricsOut = TextView(this).apply {
            textSize = 15f
            setTextIsSelectable(true)
        }
        add(resultGroup, playBtn, 0)
        add(resultGroup, saveBtn, 8)
        add(resultGroup, label("Lirik / struktur lagu dari AI"), 16)
        add(resultGroup, lyricsOut, 4)
        add(root, resultGroup, 12)
    }

    private fun add(parent: LinearLayout, child: View, topDp: Int) {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(topDp)
        parent.addView(child, lp)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun field(
        hint: String,
        lines: Int = 1,
        password: Boolean = false
    ): Pair<TextInputLayout, TextInputEditText> {
        val layout = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle)
        layout.hint = hint
        val edit = TextInputEditText(layout.context)
        when {
            password -> edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            lines > 1 -> {
                edit.inputType = InputType.TYPE_CLASS_TEXT or
                    InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                edit.minLines = lines
                edit.gravity = Gravity.TOP or Gravity.START
            }
            else -> edit.inputType = InputType.TYPE_CLASS_TEXT
        }
        layout.addView(
            edit,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        return layout to edit
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun setBusy(busy: Boolean, status: String) {
        generateBtn.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        statusText.text = status
    }

    // ---------- Generate ----------

    private fun buildPrompt(
        genre: String,
        vocal: String,
        instrumental: Boolean,
        language: String,
        desc: String,
        lyrics: String
    ): String {
        val sb = StringBuilder()
        sb.append("Create a complete, well-structured song.\n")
        sb.append("Genre: ").append(genre).append(".\n")
        if (instrumental) {
            sb.append("Instrumental only, no vocals.\n")
        } else {
            sb.append("Vocals: ").append(vocal).append(". Language of the lyrics: ").append(language).append(".\n")
        }
        if (desc.isNotBlank()) sb.append("Theme, mood and story: ").append(desc).append("\n")
        if (!instrumental) {
            if (lyrics.isNotBlank()) {
                sb.append("Use exactly these lyrics:\n").append(lyrics).append("\n")
            } else {
                sb.append("Write original lyrics that fit the theme.\n")
            }
        }
        return sb.toString()
    }

    private fun onGenerate() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("Isi kunci API dulu")
            return
        }
        val desc = descInput.text.toString().trim()
        val lyrics = lyricsInput.text.toString().trim()
        if (desc.isEmpty() && lyrics.isEmpty()) {
            toast("Isi deskripsi lagu atau lirik dulu")
            return
        }
        val model = modelInput.text.toString().trim().ifEmpty { DEFAULT_MODEL }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString("api_key", key)
            .putString("model", model)
            .apply()

        val instrumental = vocalSpinner.selectedItemPosition == vocals.lastIndex
        val prompt = buildPrompt(
            genre = genres[genreSpinner.selectedItemPosition],
            vocal = vocals[vocalSpinner.selectedItemPosition],
            instrumental = instrumental,
            language = languageNames[langSpinner.selectedItemPosition],
            desc = desc,
            lyrics = lyrics
        )

        releasePlayer()
        resultGroup.visibility = View.GONE
        setBusy(true, "Membuat lagu... bisa makan 1-3 menit, jangan tutup aplikasi.")

        executor.execute {
            try {
                val raw = requestSong(key, model, prompt)
                val parsed = Parsed()
                walk(JSONObject(raw), parsed)
                val b64 = parsed.audioB64
                    ?: throw IllegalStateException("Respons dari API tidak berisi audio. Coba lagi atau ganti model.")
                val clean = b64.substringAfter("base64,")
                val bytes = try {
                    Base64.decode(clean, Base64.DEFAULT)
                } catch (e: IllegalArgumentException) {
                    Base64.decode(clean, Base64.URL_SAFE)
                }
                val ext = if (bytes.size > 12 && String(bytes, 0, 4, Charsets.ISO_8859_1) == "RIFF") "wav" else "mp3"
                val file = File(cacheDir, "lagu_terakhir.$ext")
                file.writeBytes(bytes)
                val lyricsText = parsed.texts.joinToString("\n\n").trim()
                runOnUiThread {
                    songFile = file
                    songExt = ext
                    lyricsOut.text = if (lyricsText.isEmpty()) "(AI tidak mengirim teks lirik)" else lyricsText
                    playBtn.text = "Putar"
                    resultGroup.visibility = View.VISIBLE
                    setBusy(false, "Lagu jadi. Tekan Putar untuk mendengarkan.")
                }
            } catch (e: ApiError) {
                runOnUiThread { setBusy(false, friendlyError(e)) }
            } catch (e: Exception) {
                runOnUiThread { setBusy(false, "Gagal: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    private fun friendlyError(e: ApiError): String = when (e.code) {
        400 -> "Permintaan ditolak (400): ${e.message}"
        401, 403 -> "Kunci API ditolak (${e.code}). Cek kunci API dan pastikan akunmu boleh memakai model musik: ${e.message}"
        404 -> "Model tidak ditemukan (404). Cek nama model di kolom Model: ${e.message}"
        429 -> "Kuota atau batas permintaan habis (429): ${e.message}"
        else -> "Error ${e.code}: ${e.message}"
    }

    private fun requestSong(key: String, model: String, prompt: String): String {
        val conn = URL(ENDPOINT).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30_000
            conn.readTimeout = 600_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            val body = JSONObject().put("model", model).put("input", prompt).toString()
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw ApiError(code, extractError(text))
            return text
        } finally {
            conn.disconnect()
        }
    }

    private fun extractError(text: String): String = try {
        JSONObject(text).optJSONObject("error")?.optString("message").orEmpty().ifEmpty { text.take(300) }
    } catch (e: Exception) {
        text.take(300)
    }

    /**
     * Penelusur longgar: kumpulkan semua string di key "text" (lirik/struktur lagu) dan
     * string base64 terpanjang (audio), apa pun kedalaman/nama field-nya di steps[].content[].
     */
    private fun walk(node: Any?, out: Parsed) {
        when (node) {
            is JSONObject -> {
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = node.opt(k)
                    if (v is String) {
                        if (k == "text") {
                            if (v.isNotBlank()) out.texts.add(v)
                        } else if (v.length > 5000) {
                            val cur = out.audioB64
                            if (cur == null || v.length > cur.length) out.audioB64 = v
                        }
                    } else {
                        walk(v, out)
                    }
                }
            }
            is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), out)
        }
    }

    // ---------- Playback & save ----------

    private fun togglePlay() {
        val file = songFile ?: return
        val p = player
        try {
            if (p != null) {
                if (p.isPlaying) {
                    p.pause()
                    playBtn.text = "Putar"
                } else {
                    p.start()
                    playBtn.text = "Jeda"
                }
                return
            }
            val np = MediaPlayer()
            np.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            np.setDataSource(file.absolutePath)
            np.setOnCompletionListener {
                releasePlayer()
                playBtn.text = "Putar"
            }
            np.prepare()
            np.start()
            player = np
            playBtn.text = "Jeda"
        } catch (e: Exception) {
            releasePlayer()
            playBtn.text = "Putar"
            toast("Gagal memutar: ${e.message}")
        }
    }

    private fun releasePlayer() {
        try {
            player?.release()
        } catch (e: Exception) {
            // abaikan error saat melepas player
        }
        player = null
    }

    private fun saveToDownloads() {
        val file = songFile ?: return
        try {
            val mime = if (songExt == "wav") "audio/wav" else "audio/mpeg"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "lagu_ai_${System.currentTimeMillis()}.$songExt")
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LaguAI")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Tidak bisa membuat file di Download")
            contentResolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            }
            toast("Tersimpan di Download/LaguAI")
        } catch (e: Exception) {
            toast("Gagal menyimpan: ${e.message}")
        }
    }

    override fun onDestroy() {
        releasePlayer()
        executor.shutdown()
        super.onDestroy()
    }
}
